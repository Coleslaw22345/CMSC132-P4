package game;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;

public class DrawingTools {
	//An program to quickly print various polygons 
	public static void DrawPolygon(Graphics brush, Polygon poly) {
		//get data
		Point[] points = poly.getPoints();
		int pointCount = points.length;
		//create the two lists of points
		int[] Xcoord = new int[pointCount];
		int[] Ycoord = new int[pointCount];
		//loops over each process
		for (int i=0; i<pointCount; i++) {
			Xcoord[i] = (int) Math.round(points[i].getX());
			Ycoord[i] = (int) Math.round(points[i].getY());
		}
		brush.fillPolygon(Xcoord, Ycoord, pointCount);
	}
	
	public static void OutlinePolygon(Graphics brush, Polygon poly) {
		//get data
		Point[] points = poly.getPoints();
		int pointCount = points.length;
		//create the two lists of points
		int[] Xcoord = new int[pointCount];
		int[] Ycoord = new int[pointCount];
		//loops over each process
		for (int i=0; i<pointCount; i++) {
			Xcoord[i] = (int) Math.round(points[i].getX());
			Ycoord[i] = (int) Math.round(points[i].getY());
		}
		brush.drawPolygon(Xcoord, Ycoord, pointCount);
	}
	
	
}
