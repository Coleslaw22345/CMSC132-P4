package game;

import java.awt.Color;
import java.awt.Graphics;

public class Character extends Entity{

	private double maxHealth;
	private double health;
	
	public Character(Point[] inShape, Point inPosition, int inRotation, int H, int S) {
		super(inShape, inPosition, inRotation, S);
		maxHealth = S;
		health = H;
	}

	public double getMaxHealth() {return maxHealth;}
	public double getHealth() {return health;}
	public void setMaxHealth(double input) {maxHealth = input;}
	public void setHealth(double input) {health = input;}

	@Override
	public void draw(Graphics brush) {
		brush.setColor(Color.white);
		DrawingTools.DrawPolygon(brush, this);
		brush.setColor(Color.green);
		DrawingTools.OutlinePolygon(brush, this);
	}

}
