package game;

/*
CLASS: YourGameNameoids
DESCRIPTION: Extending Game, YourGameName is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.

*/
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
class RogueBlast extends Game implements KeyListener {
	//Variables for the game
	static int counter = 0;
	private boolean charActive = false, gameActive = false;
	private int round = 1, score = 0;
	private Character player;
	private boolean Up = false, Down = false, Left = false, Right = false;
	
  public RogueBlast() {
	//creation of the game stuff and startup before running
    super("Rogue Blast",1200,800);
    this.setFocusable(true);
	this.requestFocus();
	this.addKeyListener(this);
	Point[] square = new Point[4];
	square[0] = new Point(0, 0);
	square[1] = new Point(0, 30);
	square[2] = new Point(30, 30);
	square[3] = new Point(30, 0);
	player = new Character(square, new Point(600, 400), 0, 3, 6);
  }
  
	public void paint(Graphics brush) {
    	brush.setColor(Color.black);
    	brush.fillRect(0,0,width,height);
    	//draw entities
    	//character Moving
    	movePlayer();
    	player.draw(brush);
    	//Testing File
    	
    	//UI
    	
    	// sample code for printing message for debugging
    	// counter is incremented and this message printed
    	// each time the canvas is repainted
    	counter++;
    	brush.setColor(Color.white);
    	brush.drawString("Counter is " + counter,10,10);
  }
  
	public static void main (String[] args) {
		//start screen systems
   		RogueBlast a = new RogueBlast();
   		a.repaint();
		
  }
	
	public void movePlayer() {
		//checking if the character can move
		if (!charActive) {return;}
		//getting data
		double speed = player.getSpeed();
		//evening the vector
		if (((Up && !Down) || (Down && !Up)) && ((Left && !Right) || (Right && !Left))) {
			speed *= 0.707;
		}
		//checking Up and down movement
		if (Up && !Down) {
			player.move(0, -speed);
		} else if (Down && !Up) {
			player.move(0, speed);
		}
		//checking left and right movement
		if (Left && !Right) {
			player.move(-speed, 0);
		} else if (Right && !Left) {
			player.move(speed, 0);
		}
		//checking bounds
		double playerX = player.position.getX();
		double playerY = player.position.getY();
		
		if (playerX > 1165) {
			player.position.x = 1165;
		} else if (playerX < 5) {
			player.position.x = 5;
		}
		
		if (playerY > 740) {
			player.position.y = 740;
		} else if (playerY < 5) {
			player.position.y = 5;
		}
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
		switch (keyCode) {
			case KeyEvent.VK_W: {
				Up = true;
				break;
			}
			case KeyEvent.VK_S: {
				Down = true;
				break;
			}
			case KeyEvent.VK_A: {
				Left = true;
				break;
			}
			case KeyEvent.VK_D: {
				Right = true;
				break;
			}
			case KeyEvent.VK_SPACE: {
				if (!gameActive) {
					//Start Game
					gameActive = true;
					charActive = true;
				}
				break;
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		int keyCode = e.getKeyCode();
		
		switch (keyCode) {
			case KeyEvent.VK_W: {
				Up = false;
				break;
			}
			case KeyEvent.VK_S: {
				Down = false;
				break;
			}
			case KeyEvent.VK_A: {
				Left = false;
				break;
			}
			case KeyEvent.VK_D: {
				Right = false;
				break;
			}
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {}
}