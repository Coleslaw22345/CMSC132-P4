package game;

import java.awt.Graphics;

public abstract class Entity {
	private Point pos;
	
	private double maxHealth;
	private double health;
	private double speed;
	
	private Polygon[] model;
	
	public Entity(Polygon poly, int Health) {
		pos = new Point(50, 50);
		maxHealth = 10;
		health = 10;
		
	}
	
	
	public void draw(Graphics brush) {
		
	}
	
	public Point getPoint() {
		return this.pos;
	}
	
	public double getHealth() {
		return health;
	}
	
	public double getMaxHealth() {
		return maxHealth;
	}
	
	public Polygon[] getModel() {
		return model;
	}
	
	public abstract void damage(double damage);
}
