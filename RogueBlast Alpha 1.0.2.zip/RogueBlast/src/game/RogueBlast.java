package game;

/*
CLASS: YourGameNameoids
DESCRIPTION: Extending Game, YourGameName is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.

*/
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class RogueBlast extends Game implements MouseListener, KeyListener{
	//Variables for the game
	static int counter = 0;
	boolean charActive = false, gameActive = false;
	
  public RogueBlast() {
	//creation of the game stuff and startup before running
    super("YourGameName!",1200,800);
    this.setFocusable(true);
	this.requestFocus();
  }
  
	public void paint(Graphics brush) {
    	brush.setColor(Color.black);
    	brush.fillRect(0,0,width,height);
    	//draw entities
    	//Testing File
    	Point[] points = new Point[4];
    	
    	points[0] = new Point(0, 0);
    	points[1] = new Point(0, 120);
    	points[2] = new Point(200, 120);
    	points[3] = new Point(200, 0);
    	Point p = new Point(130, 130);
    	Polygon poly = new Polygon(points, p, counter);
    	DrawingTools.DrawPolygon(brush, poly);
    	//UI
    	
    	// sample code for printing message for debugging
    	// counter is incremented and this message printed
    	// each time the canvas is repainted
    	counter++;
    	brush.setColor(Color.white);
    	brush.drawString("Counter is " + counter,10,10);
  }
  
	public static void main (String[] args) {
		//start screen systems
   		RogueBlast a = new RogueBlast();
   		a.repaint();
		
  }

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}