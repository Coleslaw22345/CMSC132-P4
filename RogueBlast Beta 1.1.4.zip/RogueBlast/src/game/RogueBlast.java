package game;

/*
CLASS: YourGameNameoids
DESCRIPTION: Extending Game, YourGameName is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.

*/
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

@SuppressWarnings("serial")
class RogueBlast extends Game {
	
	
	
	//Variables for the game
	static int counter = 0;
	private State gameState = State.Start;
	private int pause = 0, selected = 0, wave = 0, score = 0, endTime = 0;
	
	//player variable
	static double mouseX = 0, mouseY = 0;
	private boolean Up = false, Down = false, Left = false, Right = false, firing = false;
	private Character player;
	
	//things on screen
	private ArrayList<Projectile> playerShots = new ArrayList<Projectile>();
	private ArrayList<Entity> screenEnemies = new ArrayList<Entity>();
	static public ArrayList<Projectile> enemyShots = new ArrayList<Projectile>();
	
	
	//Inner class
	MouseMotionListener Mlistener = new MouseMotionListener() {
		
		@Override
		public void mouseMoved(MouseEvent e) {
			mouseX = e.getX();
			mouseY = e.getY();
		}
		@Override
		public void mouseDragged(MouseEvent e) {}
	}; 
	
	
	
	
	
	//Other inner class
	KeyListener listener = new KeyListener() {
		@Override
		public void keyPressed(KeyEvent e) {
			int keyCode = e.getKeyCode();
			switch (keyCode) {
				case KeyEvent.VK_W: {
					//cycle upgrades
					if (gameState == State.Upgrade) {
						selected--;
						if (selected < 0) {selected = 4;}
					}
					Up = true;
					break;
				}
				case KeyEvent.VK_S: {
					//cycle upgrades
					if (gameState == State.Upgrade) {
						selected++;
						if (selected > 4) {selected = 0;}
					}
					Down = true;
					break;
				}
				case KeyEvent.VK_A: {
					Left = true;
					break;
				}
				case KeyEvent.VK_D: {
					Right = true;
					break;
				}
				case KeyEvent.VK_SPACE: {
					if (gameState == State.Start) {
						//Start Game
						pause = 10;
						gameState = State.Game;
						nextWave();
					}
					
					//upgrade selector
					if (pause <= 0 && gameState == State.Upgrade) {
						Boolean output = false;
						if (selected == 0) {
							output = player.upgradeFirerate();
						} else if (selected == 1) {
							output = player.upgradeHealth();
						} else if (selected == 2) {
							output = player.upgradeShotSpeed();
						} else if (selected == 3) {
							output = player.upgradeSpeed();
						} else {
							output = player.heal();
						}
						if (output) {
							pause = 15;
							gameState = State.Game;
							nextWave();
						}
					}
					//firing function
					firing = true;
					break;
				}
			}
		}
		
		//key relese events, simple
		@Override
		public void keyReleased(KeyEvent e) {
			int keyCode = e.getKeyCode();
			
			switch (keyCode) {
				case KeyEvent.VK_W: {
					Up = false;
					break;
				}
				case KeyEvent.VK_S: {
					Down = false;
					break;
				}
				case KeyEvent.VK_A: {
					Left = false;
					break;
				}
				case KeyEvent.VK_D: {
					Right = false;
					break;
				}
				case KeyEvent.VK_SPACE: {
					firing = false;
					break;
				}
			}
		}
		@Override
		public void keyTyped(KeyEvent e) {}
	};
	
	
	
	//constructor of the orginal game stuff
  public RogueBlast() {
	//creation of the game stuff and startup before running
    super("Rogue Blast",1200,800);
    this.setFocusable(true);
	this.requestFocus();
	this.addKeyListener(listener);
	this.addMouseMotionListener(Mlistener);
	Point[] square = new Point[5];
	square[0] = new Point(0, 20);
	square[1] = new Point(20, 0);
	square[2] = new Point(40, 20);
	square[3] = new Point(40, 50);
	square[4] = new Point(0, 50);
	player = new Character(square, new Point(600, 400), 0, 3, 4);
  }
  
  
  
  
	public void paint(Graphics brush) {
    	//Background
		brush.setColor(Color.black);
    	brush.fillRect(0,0,width,height);
    	
    	//The different game states
    	switch (gameState) {
		case End:
			drawEndScreen(brush);
			break;
		case Game:
			gameloop(brush);
			break;
		case Start:
			drawStartScreen(brush);
			break;
		case Upgrade:
			upgradeScreen(brush);
			break;
		default:
			break;
    	}
    	//counter
    	counter++;
    	if (pause > 0) {
    		pause--;
    	}
    	brush.setColor(Color.white);
    	brush.drawString("Counter is " + counter,10,10);
  }
  
	//Starting method
	public static void main (String[] args) {
		//start screen systems
   		RogueBlast a = new RogueBlast();
   		a.repaint();
		
  }
	
	
	
	
	public void movePlayer() {
		//getting data
		double speed = player.getSpeed();
		//evening the vector
		if (((Up && !Down) || (Down && !Up)) && ((Left && !Right) || (Right && !Left))) {
			speed *= 0.707;
		}
		//checking Up and down movement
		if (Up && !Down) {
			player.move(0, -speed);
		} else if (Down && !Up) {
			player.move(0, speed);
		}
		//checking left and right movement
		if (Left && !Right) {
			player.move(-speed, 0);
		} else if (Right && !Left) {
			player.move(speed, 0);
		}
		//checking bounds
		double playerX = player.position.getX();
		double playerY = player.position.getY();
		
		if (playerX > 1145) {
			player.position.x = 1145;
		} else if (playerX < 0) {
			player.position.x = 0;
		}
		
		if (playerY > 710) {
			player.position.y = 710;
		} else if (playerY < -15) {
			player.position.y = -15;
		}
	}
	
	
	
	
	public void drawStartScreen(Graphics brush) {
		brush.setColor(Color.white);
		brush.drawRect(480, 350, 240, 100);
		brush.fillRect(490, 360, 220, 80);
		brush.setColor(Color.black);
		brush.fillRect(495, 365, 210, 70);
		brush.setColor(Color.white);
		brush.drawString("Press Space", 570, 405);
		brush.drawString("Space : Shoot", 570, 515);
		brush.drawString("Mouse : Aim", 570, 530);
		brush.drawString("ASWD : Move", 570, 545);
		brush.drawString("Fight To The END", 558, 315);
		brush.drawString("Rogue Blast", 570, 300);
		
		DrawSpinningCharacter(brush, new Point(800, 400));
	}
	
	
	
	
	public void drawEndScreen(Graphics brush) {
		//end box
		brush.setColor(Color.white);
		brush.drawRect(480, 350, 240, 100);
		brush.fillRect(490, 360, 220, 80);
		brush.setColor(Color.black);
		brush.fillRect(495, 365, 210, 70);
		brush.setColor(Color.white);
		brush.drawString("Game OVER!!", 570, 405);
		brush.drawString("Score : " + score, 570, 500);
		brush.drawString("Time : " + ((double) endTime/100) + "s", 570, 515);
		//TODO score showing
		//rotating character
		DrawSpinningCharacter(brush, new Point(800, 400));
	}
	
	
	
	
	//Importatnt GameLoop function
	public void gameloop(Graphics brush) {
		//Player Shooting
		if (firing && (pause <= 0)) {
    		Projectile shot = player.attackAttempt(counter);
    		if (shot != null) {
    			playerShots.add(shot);
    		}
    	} 
		
		//Drawing the game
		movePlayer();
    	player.draw(brush, counter);
    	
    	//calculating the current game projectiles
    	ArrayList<Projectile> removing = new ArrayList<Projectile>();
    	ArrayList<Entity> hitEnemies = new ArrayList<Entity>();
    	for (Projectile projectile : playerShots) {
			if (projectile.projectileDone(counter)) {
				removing.add(projectile);
			} else {
				projectile.draw(brush, counter);
			}
			//enemy damaged function here
			if (removing.contains(projectile) == false) {
				for (Entity e : screenEnemies) {
					if (removing.contains(projectile) == false) {
						if (e.contains(projectile.position)) {
							removing.add(projectile);
							hitEnemies.add(e);
						}
					}
				}
			}
		}
    	
    	//removing unnecessary shots and enemies
    	while (removing.size() > 0) {
    		playerShots.remove(removing.get(0));
    		removing.remove(0);
    	}
    	while (hitEnemies.size() > 0) {
    		if (hitEnemies.get(0) instanceof Enemy) {
				score += ((Enemy) hitEnemies.get(0)).getValue();
			}
    		screenEnemies.remove(hitEnemies.get(0));
    		hitEnemies.remove(0);
    	}
    	
    	//enemy shots
    	ArrayList<Projectile> enemyRemoving = new ArrayList<Projectile>();
    	for (Projectile projectile : enemyShots) {
    		if (projectile.projectileDone(counter)) {
    			enemyRemoving.add(projectile);
			} else {
				projectile.draw(brush, counter);
			}
			//enemy damaged function here
			if (enemyRemoving.contains(projectile) == false) {
				if (player.contains(projectile.position)) {
					enemyRemoving.add(projectile);
					player.damageCharacter();
				}
			}
    	}
    	while (enemyRemoving.size() > 0) {
    		enemyShots.remove(enemyRemoving.get(0));
    		enemyRemoving.remove(0);
    	}
    	
    	//enemy AI
    	for (Entity entity : screenEnemies) {
			if (entity instanceof Enemy) {
				((Enemy) entity).enemyAI(brush, counter, player);
			}
		}
    	
    	//check player hasent died
    	if (player.getHealth() <= 0) {
    		endTime = counter;
    		gameState = State.End;
    	} else if (screenEnemies.size() <= 0) {
    		pause = 15;
    		gameState = State.Upgrade;
    	}
	}
	
	
	
	
	public void upgradeScreen(Graphics brush) {
		brush.setColor(Color.white);
		brush.drawRect(480, 225, 240, 100);
		brush.drawRect(480, 350, 240, 100);
		brush.drawRect(480, 475, 240, 100);
		brush.drawRect(480, 600, 240, 100);
		brush.drawRect(480, 100, 240, 100);
		brush.setColor(Color.red);
		brush.drawString("Improve Firerate!", 540, 160);
		brush.drawString("Improve Health!", 540, 285);
		brush.drawString("Improve Bullet Speed!", 540, 410);
		brush.drawString("Improve Movement!", 540, 535);
		brush.drawString("Recover Health!", 540, 660);
		brush.setColor(Color.white);
		brush.drawString("W : Select Up", 200, 200);
		brush.drawString("S : Select Down", 200, 215);
		//Selector
		Point[] square = new Point[5];
		square[0] = new Point(0, 20);
		square[1] = new Point(20, 0);
		square[2] = new Point(40, 20);
		square[3] = new Point(40, 50);
		square[4] = new Point(0, 50);
		Polygon shape = new Polygon(square, new Point(800,125+(selected * 125)), 270);
		brush.setColor(Color.white);
		DrawingTools.OutlinePolygon(brush, shape);
	}
	
	
	
	
	public void DrawSpinningCharacter(Graphics brush, Point a) {
		Point[] square = new Point[5];
		square[0] = new Point(0, 20);
		square[1] = new Point(20, 0);
		square[2] = new Point(40, 20);
		square[3] = new Point(40, 50);
		square[4] = new Point(0, 50);
		Polygon shape = new Polygon(square, a, counter);
		brush.setColor(Color.white);
		DrawingTools.OutlinePolygon(brush, shape);
	}
	
	
	
	
	public void nextWave() {
		Point[] square = new Point[4];
		square[0] = new Point(0,0);
		square[1] = new Point(0,30);
		square[2] = new Point(30,30);
		square[3] = new Point(30,0);
		
		Point[] triangle = new Point[3];
		triangle[0] = new Point(0, 40);
		triangle[1] = new Point(40,40);
		triangle[2] = new Point(20, 0);
		
		Point[] hexagon = new Point[6];
		hexagon[0] = new Point(0,0);
		hexagon[1] = new Point(0,30);
		hexagon[2] = new Point(15,40);
		hexagon[3] = new Point(30,30);
		hexagon[4] = new Point(30,0);
		hexagon[5] = new Point(15,-10);
		
		wave++;
		score += (wave-1) * 3;
		System.out.println("Start");
		if (wave == 1) {
			screenEnemies.add(new SmallEnemy(square, new Point(100, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(300, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(500, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(700, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(900, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(1100, -10), 0, 3, 2));
		} else if (wave == 2) {
			screenEnemies.add(new SmallEnemy(square, new Point(400, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(600, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(400, 810), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, 810), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(600, 810), 0, 3, 2));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 500), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 500), 0, 2, 3));
		} else if (wave == 3) {
			screenEnemies.add(new SmallEnemy(square, new Point(400, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(600, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(400, 810), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, 810), 0, 3, 2));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, 810), 0, 2, 4));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, -10), 0, 2, 4));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 500), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 500), 0, 2, 3));
		} else if (wave == 4) {
			screenEnemies.add(new SmallEnemy(square, new Point(400, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(600, -10), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(400, 810), 0, 3, 2));
			screenEnemies.add(new SmallEnemy(square, new Point(800, 810), 0, 3, 2));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, 810), 0, 2, 4));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, -10), 0, 2, 4));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-10, 500), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1210, 500), 0, 2, 3));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, 860), 0, 2, 4));
			screenEnemies.add(new SniperEnemy(hexagon, new Point(600, -60), 0, 2, 4));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-60, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(-60, 500), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1260, 300), 0, 2, 3));
			screenEnemies.add(new ShooterEnemy(triangle, new Point(1260, 500), 0, 2, 3));
		} else {
			for (int i=0; i <= wave; i++) {
				for (int h=0; h < 2; h++) {
					screenEnemies.add(new SmallEnemy(square, new Point(200+(h*300), -10*i), 0, 3, 2));
					screenEnemies.add(new SniperEnemy(hexagon, new Point(300+(h*300), -10*i), 0, 2, 4));
					screenEnemies.add(new ShooterEnemy(triangle, new Point(400+(h*300), -10*i), 0, 2, 3));
				}
			}
		}
			//screenEnemies.add(new SmallEnemy(square, new Point(0, 0), 0, 3, 2));
			//screenEnemies.add(new ShooterEnemy(triangle, new Point(0, 0), 0, 2, 3));
			//screenEnemies.add(new SniperEnemy(hexagon, new Point(0, 0), 0, 2, 4));
	}
}