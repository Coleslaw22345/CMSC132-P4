package game;

import java.awt.Graphics;
@FunctionalInterface
public interface HasDraw {
	public void draw(Graphics brush, int time);
}
