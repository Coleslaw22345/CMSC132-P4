package game;

import java.awt.Graphics;

public abstract class Entity extends Polygon implements HasDraw {
	
	private double speed;
	
	public Entity(Point[] inShape, Point inPosition, double inRotation, double S) {
		super(inShape, inPosition, inRotation);
		speed = S;
	}
	
	public double getSpeed() {return speed;}
	public void setSpeed(double input) {speed = input;}
	
	public abstract void draw(Graphics brush, int time);
	
	public void move(double x, double y) {
		this.position.x += x;
		this.position.y += y;
	}
}
