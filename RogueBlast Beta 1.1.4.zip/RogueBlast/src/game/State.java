package game;

public enum State {
	Start, Game, End, Upgrade;
}
