package game;

import java.awt.Color;
import java.awt.Graphics;

public class SmallEnemy extends Entity implements HasDraw, Enemy {
	
	private final int cooldown = 50;
	private int hit = 0;
	private int value = 2;
	
	public SmallEnemy(Point[] inShape, Point inPosition, double inRotation, double S, int v) {
		super(inShape, inPosition, inRotation, S);
		value = v;
	}

	@Override
	public void draw(Graphics brush, int time) {
		brush.setColor(Color.red);
		DrawingTools.OutlinePolygon(brush, this);
	}

	@Override
	public boolean enemyAI(Graphics brush, int time, Character player) {
		double deltaX = player.position.x - position.x - 20;
		double deltaY = player.position.y - position.y - 25;
		//using arctan to shift the slope to degrees
		double angleRadians = Math.atan2(deltaX, -1*deltaY);
		double angleDegrees = Math.toDegrees(angleRadians);
		//normalizing
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		//apply changes
		rotate(angleDegrees - rotation);
		
		Point vector = DrawingTools.NormalizedSlope(position, player.position);
		move(vector.x * getSpeed(), vector.y * getSpeed());
		
		draw(brush, time);
		
		for (Point p : this.getPoints()) {
			if (player.contains(p) && ((time - hit) > cooldown)) {
				player.damageCharacter();
				hit = time;
				return true;
			}
		}
		return false;
		// TODO Auto-generated method stub
	}

	@Override
	public int getValue() {
		return value;
	}
}
