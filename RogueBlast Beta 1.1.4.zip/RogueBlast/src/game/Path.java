package game;

@FunctionalInterface
public interface Path {
	public Point calculatePoint(Point a, Point b, double percentTraveled);
}
