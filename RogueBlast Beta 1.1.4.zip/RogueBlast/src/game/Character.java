package game;

import java.awt.Color;
import java.awt.Graphics;

public class Character extends Entity{

	private int maxHealth = 3;
	private int health = 3;
	private int Cooldown = 50;
	private int lastShot = 0;
	private int shotSpeed = 250;
	
	public Character(Point[] inShape, Point inPosition, int inRotation, int H, int S) {
		super(inShape, inPosition, inRotation, S);
		maxHealth = H;
		health = H;
	}
	
	//make these boolean within rights //TODO
	public boolean upgradeSpeed() {
		if (getSpeed() < 10) {
			setSpeed(getSpeed()+1);
			return true;
		}
		return false;
	}
	
	public boolean upgradeHealth() {
		maxHealth++; 
		health++;
		return true;
	}
	
	public boolean upgradeFirerate() {
		if (Cooldown > 5) {
			Cooldown -= Cooldown/6;
			if (Cooldown < 5) {
				Cooldown = 5;
			}
			return true;
		}
		return false;
	}
	
	public boolean upgradeShotSpeed() {
		System.out.println("Attempted Upgrade");
		if (shotSpeed > 15) {
			shotSpeed -= 15;
			if (shotSpeed < 15) {
				shotSpeed = 15;
			}
			return true;
		}
		return false;
	}
	
	public boolean heal() {
		boolean output = false;
		if (health < maxHealth) {
			health++;
			if (health > maxHealth) {
				health = maxHealth;
			}
			output = true;
		}
		return output;
	}
	
	public boolean damageCharacter() {
		System.out.println("Damge");
		health--;
		if (health <= 0) {
			return true;
		}
		return false;
	}
	
	public Projectile attackAttempt(int time) {
		if ((time - lastShot) > Cooldown) {
			//fire the shot
			double mouseX = RogueBlast.mouseX;
			double mouseY = RogueBlast.mouseY;
			Point b = new Point(mouseX, mouseY);
			Point a = new Point(position.x + 20, position.y + 25);
			Point vector = DrawingTools.NormalizedSlope(a, b);
			
			Point end = new Point(a.x + (1500*vector.x), a.y + (1500*vector.y));
			
			Point[] shape = new Point[4];
			shape[0] = new Point(6, 0);
			shape[1] = new Point(12, 6);
			shape[2] = new Point(6, 18);
			shape[3] = new Point(0, 6);
			
			Path movement = (start, finish, percent) -> {
				double deltaX = (finish.x - start.x) * percent;
				double deltaY = (finish.y - start.y) * percent;
				return new Point(deltaX + start.x, deltaY + start.y);
			};
			
			Projectile shot = new Projectile(shape, a, end, rotation, 0, movement, Color.white, shotSpeed, time);
			lastShot = time;
			return shot;
		}
		return null;
	}
	
	public void rotateToCamera() {
		//getting mouse position
		double mouseX = RogueBlast.mouseX;
		double mouseY = RogueBlast.mouseY;
		//finding the difference
		double deltaX = mouseX - position.x - 20;
		double deltaY = mouseY - position.y - 25;
		//using arctan to shift the slope to degrees
		double angleRadians = Math.atan2(deltaX, -1*deltaY);
		double angleDegrees = Math.toDegrees(angleRadians);
		//normalizing
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		//apply changes
		rotate(angleDegrees - rotation);
	}
	
	@Override
	public void draw(Graphics brush, int time) {
		rotateToCamera();
		//brush.setColor(Color.white);
		//DrawingTools.DrawPolygon(brush, this);
		brush.setColor(Color.white);
		DrawingTools.OutlinePolygon(brush, this);
	}
	
	public int getHealth() {return health;}
}
