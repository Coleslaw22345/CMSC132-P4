package game;

import java.awt.Color;
import java.awt.Graphics;

public class Projectile extends Polygon implements HasDraw {
	private Point start, finish;
	private int duration, startTime;
	private Path movement;
	private Color color;
	
	public Projectile(Point[] inShape, Point start, Point finish, double inRotation, double S, Path movement, Color color, int duration, int time) {
		super(inShape, start, inRotation);
		this.movement = movement;
		this.start = start;
		this.finish = finish;
		this.color = color;
		this.duration = duration;
		this.startTime = time;
	}

	public void draw(Graphics brush, int time) {
		//get the location from the interface
		
		int deltaTime = time - startTime;
		double percentTraveled = (double) deltaTime/duration;
		Point newLocation = movement.calculatePoint(start, finish, percentTraveled);
		Point oldLocation = this.position;
		// rotating the object
		//finding the difference
		double deltaX = newLocation.x - oldLocation.x - 0; //test this (width and height + 10
		double deltaY = newLocation.y - oldLocation.y + 0;
		//using arctan to shift the slope to degrees
		double angleRadians = Math.atan2(deltaX, -1*deltaY);
		double angleDegrees = Math.toDegrees(angleRadians);
		//normalizing
		if (angleDegrees < 0) {
		    angleDegrees += 360;
		}
		//apply changes
		rotate(angleDegrees - rotation);
		this.position = newLocation;
		//apply location and calculate rotations using character as a base
		//TODO
		brush.setColor(color);
		DrawingTools.DrawPolygon(brush, this);
	}
	
	public boolean projectileDone(int time) {
		return (time > duration + startTime);
	}
}
