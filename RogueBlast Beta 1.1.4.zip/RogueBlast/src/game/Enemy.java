package game;

import java.awt.Graphics;

public interface Enemy {
	public boolean enemyAI(Graphics brush, int time, Character player);
	public int getValue();
}
