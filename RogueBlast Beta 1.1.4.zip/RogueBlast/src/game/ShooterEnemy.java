package game;

import java.awt.Color;
import java.awt.Graphics;

public class ShooterEnemy extends Entity implements HasDraw, Enemy {
	
	private final int cooldown = 50;
	private final int shootCooldown = 80;
	private int lastshot;
	private int hit = 0;
	private int value = 3;
	
	public ShooterEnemy(Point[] inShape, Point inPosition, double inRotation, double S, int v) {
		super(inShape, inPosition, inRotation, S);
		value = v;
	}

	@Override
	public void draw(Graphics brush, int time) {
		brush.setColor(Color.pink);
		DrawingTools.OutlinePolygon(brush, this);
	}

	@Override
	public boolean enemyAI(Graphics brush, int time, Character player) {
		double deltaX = player.position.x - position.x - 20;
		double deltaY = player.position.y - position.y - 20;
		//using arctan to shift the slope to degrees
		double angleRadians = Math.atan2(deltaX, -1*deltaY);
		double angleDegrees = Math.toDegrees(angleRadians);
		//normalizing
		if (angleDegrees < 0) {
			angleDegrees += 360;
		}
		//apply changes
		rotate(angleDegrees - rotation);
		
		
		if (DrawingTools.Distance(position, player.position) > 320) {
			Point vector = DrawingTools.NormalizedSlope(position, player.position);
			move(vector.x * getSpeed(), vector.y * getSpeed());
		} else {
			rangedAttack(brush, time, player);
		}
		
		draw(brush, time);
		
		for (Point p : this.getPoints()) {
			if (player.contains(p) && ((time - hit) > cooldown)) {
				player.damageCharacter();
				hit = time;
				return true;
			}
		}
		return false;
		// TODO Auto-generated method stub
	}

	@Override
	public int getValue() {
		return value;
	}
	
	public void rangedAttack(Graphics brush, int time, Character player) {
		if ((time - lastshot) > shootCooldown) {
			//fire the shot
			Point b = player.position;
			Point a = new Point(position.x + 20, position.y + 25);
			Point vector = DrawingTools.NormalizedSlope(a, b);
			
			Point end = new Point(a.x + (1500*vector.x), a.y + (1500*vector.y));
			
			Point[] shape = new Point[4];
			shape[0] = new Point(6, 0);
			shape[1] = new Point(12, 6);
			shape[2] = new Point(6, 18);
			shape[3] = new Point(0, 6);
			
			Path movement = (start, finish, percent) -> {
				double deltaX = (finish.x - start.x) * percent;
				double deltaY = (finish.y - start.y) * percent;
				return new Point(deltaX + start.x, deltaY + start.y);
			};
			
			Projectile shot = new Projectile(shape, a, end, rotation, 0, movement, Color.pink, 400, time);
			lastshot = time;
			RogueBlast.enemyShots.add(shot);
		}
	}
}
