package model;

/**
 * Represents the &lt;table&gt tag.
 * A two dimensional array is used to keep track of the Element objects of table.
 * @author UMCP
 *
 */
public class TableElement extends TagElement {
	private Element[][] items;
	
	public TableElement(int rows, int cols, String attributes) {
		super("table", true, null, attributes);
		this.items = new Element[rows][cols];
	}
	
	public void addItem(int rowIndex, int colIndex, Element item) {
		this.items[rowIndex][colIndex] = item;
	}
	
	public double getTableUtilization() {
		int total = items.length * items[1].length;
		int usedCells = 0;
		for (Element[] elements : items) {
			for (Element ELE : elements) {
				if (ELE != null) {
					usedCells++;
				}
			}
		}
		return usedCells*100/total;
	}
	
	@Override
	public String genHTML(int indentation) {
		//not sure if this is right
		//this will be the biggest source of issues
		String output = "";
		output += getStartTag();
		for (int i = 0; i < this.items.length; i++) {
			output += "\n   <tr>";
			for (int h = 0; h < items[i].length; h++) {
				output += "<td>";
				if (items[i][h] != null) {
					output += items[i][h].genHTML(0);
				}
				output += "</td>";
			}
			output += "</tr>";
		}
		output += "\n";
		output += getEndTag();
		output = output.indent(indentation);
		return output;
	}
}
