package model;

import java.util.ArrayList;

/**
 * 
 * Represents a paragraph (&lt;p&gt;) tag.  It relies on an
 * ArrayList in order to keep track of the set of Element objects
 * that are part of the paragraph.
 * @author UMCP
 *
 */
public class ParagraphElement extends TagElement {
	private ArrayList<Element> items;
	
	public ParagraphElement(String attributes) {
		super("p", true, null, attributes);
		this.items = new ArrayList<Element>();
		// TODO Auto-generated constructor stub
	}
	
	public void addItem(Element item) {
		this.items.add(item);
	}
	
	@Override
	public String genHTML(int indentation) {
		//not sure if this is right
		//this will be the biggest source of issues
		String output = Utilities.defaultSpaces(indentation);
		output += getStartTag();
		if (this.items.isEmpty() == false) {
			for (int i = 0; i < this.items.size(); i++) {
				output += "\n" + this.items.get(i).genHTML(indentation + 1);
			}
			output += "\n" + Utilities.defaultSpaces(indentation);
		}
		output += getEndTag();
		return output;
	}
	
}
