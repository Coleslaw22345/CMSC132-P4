package model;

/**
 * 
 * Represents an HTML tag element (<&lt;p&gt;, &lt;ul&gt;, etc.).
 * Each tag has an id (ids start at 1).  By default the start tag
 * will have an id (e.g., <&lt;p id="a1"&gt;&lt;/p&gt;) when
 * the HTML for the tag is generated.  This can be disabled by
 * using enableId.
 * @author UMCP
 *
 */
public class TagElement implements Element {
	private static int nextID = 1;
	private static boolean IDEnabled = true;
	private int ID;
	private String tagName;
	private boolean addendTag;
	private Element content;
	private String attributes;
	
	
	public TagElement(String tagName, boolean addendTag, Element content, String attributes) {
		this.ID = nextID;
		nextID += 1;
		this.tagName = new String(tagName);
		this.addendTag = addendTag;
		this.content = content;
		if (attributes != null) {
			this.attributes = new String(attributes);
		}
	}
	
	public int getId() {
		return this.ID;
	}
	
	public String getStringId() {
		//not sure if this is setup correctly
		String output = new String(this.tagName);
		output += this.ID;
		return output;
	}
	
	public String getStartTag() {
		String output = "<";
		output += this.tagName;
		if (IDEnabled) {
			output += " id=\"" + getStringId() + "\"";
		}
		if (this.attributes != null && this.attributes.isBlank() == false) {
			output += " " + this.attributes;
		}
		output += ">";
		return output;
	}
	
	public String getEndTag() {
		if (this.addendTag) {
			return "</" + this.tagName + ">";
		}
		return "";
	}
	
	public void setAttributes​(String attributes) {
		this.attributes = new String(attributes);
	}
	
	public static void resetIds() {
		nextID = 1;
	}
	
	public static void enableId(boolean choice) {
		IDEnabled = choice;
	}
	
	@Override
	public String genHTML(int indentation) {
		//not sure if this is right
		//this will be the biggest source of issues
		String output = Utilities.defaultSpaces(indentation);
		output += getStartTag();
		if (this.content != null) {
			output += content.genHTML(0);
		}
		output += getEndTag();
		return output;
	}

}