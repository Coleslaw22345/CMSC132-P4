package model;

import java.util.*;

/**
 * Represents a web page.  Web page elements are
 * stored in an ArrayList of Element objects.  A title
 * is associated with every page.  This class implements
 * the Comparable interface.  Pages will be compared
 * based on the title.
 * @author UMCP
 *
 */
public class WebPage implements Comparable<WebPage> {
	private ArrayList<Element> elements;
	private String title;
	
	//constructor done
	public WebPage(java.lang.String title) {
		this.title = new String(title);
		this.elements = new ArrayList<Element>();
	}
	
	//done
	public int addElement(Element element) {
		if (element != null) {
			elements.add(element);
		}
		if (element instanceof TagElement) {
			TagElement ele = (TagElement) element;
			return ele.getId();
		} else {
			return -1;
		}
	}
	
	//not my problem??
	@Override
	public int compareTo(WebPage o) {
		return 0;
	}
	
	//done
	public static void enableId​(boolean choice) {
		TagElement.enableId(choice);
	}
	
	//done
	public Element findElem(int id) {
		for (Element element : elements) {
			if (element != null && element instanceof TagElement) {
				TagElement TE = (TagElement) element;
				if (TE.getId() == id) {
					return TE;
				}
			}
		}
		return null;
	}
	
	//solved
	public String getWebPageHTML(int indentation) {
		Utilities.DEFAULT_INDENTATION = indentation;
		String output = "<!doctype html>\n<html>";
		output += "\n" + Utilities.defaultSpaces(1) + "<head>";
		output += "\n" + Utilities.defaultSpaces(2) + "<meta charset=\"utf-8\"/>";
		output += "\n" + Utilities.defaultSpaces(2) + "<title>" + this.title + "</title>";
		output += "\n" + Utilities.defaultSpaces(1) + "</head>";
		output += "\n" + Utilities.defaultSpaces(1) + "<body>";
		
		for (int i=0; i<elements.size(); i++) {
			output += "\n" + elements.get(i).genHTML(1);
		}
		
		output += "\n" + Utilities.defaultSpaces(1) + "</body>";
		output += "\n</html>";
		return output;
	}
	
	//problem
	public String stats() {
		String output = "";
		int listCount = 0;
		int paraCount = 0;
		int tableCount = 0;
		double tableUtiliztotal = 0;
		
		for (Element element : elements) {
			if (element instanceof ListElement) {
				listCount++;
			} else if (element instanceof ParagraphElement) {
				paraCount++;
			} else if (element instanceof TableElement) {
				tableCount += 1;
				tableUtiliztotal += ((TableElement) element).getTableUtilization();
			}
		}
		
		output += "List Count: " + listCount + "\n";
		output += "Paragraph Count: " + paraCount + "\n";
		output += "Table Count: " + tableCount + "\n";
		output += "TableElement Utilization: " + (tableUtiliztotal/tableCount);
		return output;
	}
	
	//done
	public void writeToFile​(String filename, int indentation) {
		Utilities.writeToFile(filename, getWebPageHTML(indentation));
	}
}
