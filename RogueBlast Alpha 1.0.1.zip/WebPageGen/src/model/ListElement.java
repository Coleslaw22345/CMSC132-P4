package model;

import java.util.ArrayList;

/**
 * Represents the &lt;ul&gt and the &lt;ol&gt; tags.
 * An ArrayList is used to keep track of the Element objects of the list.
 * @author UMCP
 *
 */
public class ListElement extends TagElement {
	private ArrayList<Element> items;
	
	public ListElement(boolean ordered, String attributes) {
		super((ordered ? "ol" : "ul"), true, null, attributes);
		this.items = new ArrayList<Element>();
	}
	
	public void addItem(Element item) {
		this.items.add(item);
	}
	
	@Override
	public String genHTML(int indentation) {
		//not sure if this is right
		//this will be the biggest source of issues
		String output = "";
		output += getStartTag();
		if (this.items.isEmpty() == false) {
			for (int i = 0; i < this.items.size(); i++) {
				output += "\n   <li>";
				output += "\n" + this.items.get(i).genHTML(6);
				output += "\n   </li>";
			}
			output += "\n";
		}
		output += getEndTag();
		output = output.indent(indentation);
		return output;
	}
}
