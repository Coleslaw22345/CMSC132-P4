package model;

/**
 * Represents the &lt;a&gt; tag.
 * @author UMCP
 *
 */
public class AnchorElement extends TagElement {
	private String linkText;
	private String url;

	public AnchorElement(String url, String linkText, String attributes) {
		super("a", true, null, attributes);
		
		this.linkText = new String(linkText);
		this.url = new String(url);
		
		String updatedAttributes = "href=\"" + url + "\"";
		if (attributes != null) {
			updatedAttributes += " " + attributes;
		}
		super.setAttributes​(updatedAttributes);
	}
	
	public String getLinkText() {
		return new String(this.linkText);
	}
	
	public String getUrlText() {
		return new String(this.url);
	}
	
	@Override
	public String genHTML(int indentation) {
		//not sure if this is right
		//this will be the biggest source of issues
		String output = Utilities.defaultSpaces(indentation);
		output += getStartTag();
		output += new TextElement(this.linkText).genHTML(0);
		output += getEndTag();
		return output;
	}
	
}
