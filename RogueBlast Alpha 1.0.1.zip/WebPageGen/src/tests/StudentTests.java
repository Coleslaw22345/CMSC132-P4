package tests;

import static org.junit.Assert.*;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.AnchorElement;
import model.HeadingElement;
import model.ListElement;
import model.TagElement;
import model.TextElement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {

	@Test
	public void test() {
		String testName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		int indentation = 3;
		String answer = "", attributes = null;

		boolean orderedList = false;
		TagElement.resetIds();
		TagElement.enableId(true);
		ListElement element = new ListElement(orderedList, attributes);
		element.addItem(new TextElement("Superman"));
		element.addItem(new AnchorElement("http://www.cs.umd.edu", "UMD", attributes));
		answer += element.genHTML(indentation);
		answer += "\nSecondElement\n";

		indentation = 6;
		orderedList = true;
		attributes = "reversed";
		ListElement element2 = new ListElement(orderedList, attributes);
		element2.addItem(new TextElement("Superman"));
		element2.addItem(new TextElement("Batman"));
		answer += element2.genHTML(indentation);

		assertTrue(TestingSupport.isResultCorrect(testName, answer, true));
	}

}
