package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import tubeVideosManager.Genre;
import tubeVideosManager.Video;

/**
 * 
 * You need student tests if you are asking for help during
 * office hours about bugs in your code. Feel free to use
 * tools available in TestingSupport.java
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void testVideoClass() {
		Video vidTest = new Video("Title goes Here", "U R L,    no,    U TAKE L", 30, Genre.FilmAnimation);
		assertTrue(vidTest.getDurationInMinutes() == 30);
		assertTrue(vidTest.getUrl().equals("U R L,    no,    U TAKE L"));
		assertTrue(vidTest.getTitle().equals("Title goes Here"));
		assertTrue(vidTest.getGenre().equals(Genre.FilmAnimation));
		Video newVid = new Video(vidTest);
		newVid.addComments("One Really Negitive Comment");
		assertTrue(vidTest.getComments().size() == 0);
		assertTrue(newVid.getComments().size() == 1);
		assertTrue(vidTest.toString().equals(newVid.toString()));
	}
	
	@Test
	public void testPlaylistClass() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testVideoManagerClass() {
		fail("Not yet implemented");
	}
}
