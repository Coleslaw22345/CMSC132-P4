package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import model.BoardCell;
import model.Game;
import model.ProcessCellGame;

/* The following directive executes tests in sorted order */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	
	/* Remove the following test and add your tests */
	@Test
	public void GameFunctions() {
		String output = "";
		int maxRows = 7, maxCols = 23, strategy = 1;
		ProcessCellGame g = new ProcessCellGame(maxRows, maxCols, new Random(124), strategy);
		g.setBoardWithColor(BoardCell.GREEN);
		g.setColWithColor(6, BoardCell.RED);
		g.setRowWithColor(3, BoardCell.YELLOW);
		g.setBoardCell(3, 6, BoardCell.BLUE);
		
		output += g.getMaxCols() + ", ";
		output += g.getMaxRows() + ", ";
		output += g.getScore() + ", ";
		
		assertTrue(output.equals("23, 7, 0, "));
	}
	@Test
	public void GameMapping() {
		String output = "";
		int maxRows = 3, maxCols = 6, strategy = 1;
		ProcessCellGame g = new ProcessCellGame(maxRows, maxCols, new Random(124), strategy);
		g.setBoardWithColor(BoardCell.GREEN);
		g.setColWithColor(6-1, BoardCell.RED);
		g.setRowWithColor(3-1, BoardCell.YELLOW);
		g.setBoardCell(3-1, 6-1, BoardCell.BLUE);
		
		output += getBoardStr(g);
		
		assertTrue(output.equals("Board(Rows: 3, Columns: 6)\nGGGGGR\nGGGGGR\nYYYYYB\n"));
	}
	
	@Test
	public void GameFraming() {
		String output = "";
		int maxRows = 3, maxCols = 6, strategy = 1;
		ProcessCellGame g = new ProcessCellGame(maxRows, maxCols, new Random(124), strategy);
		
		g.nextAnimationStep();
		g.nextAnimationStep();
		
		output += getBoardStr(g);
		
		assertTrue(output.equals("Board(Rows: 3, Columns: 6)\nBBYRRR\nRBBGGG\n......\n"));
	}
	
	@Test
	public void GameTesting() {
		String output = "";
		int maxRows = 3, maxCols = 6, strategy = 1;
		ProcessCellGame g = new ProcessCellGame(maxRows, maxCols, new Random(124), strategy);
		g.setBoardWithColor(BoardCell.GREEN);
		g.setColWithColor(6-1, BoardCell.RED);
		g.setRowWithColor(3-1, BoardCell.EMPTY);
		g.setBoardCell(3-2, 6-1, BoardCell.BLUE);
		
		g.processCell(0, 0);
		
		output += getBoardStr(g);
		System.out.println(output);
		
		assertTrue(output.equals("Board(Rows: 3, Columns: 6)\n.....R\n..GGGB\n......\n"));
	}
	
	//Stole this code to help my test ; )
	private static String getBoardStr(Game game) {
		int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += game.getBoardCell(row, col).getName();
			}
			answer += "\n";
		}

		return answer;
	}
}
