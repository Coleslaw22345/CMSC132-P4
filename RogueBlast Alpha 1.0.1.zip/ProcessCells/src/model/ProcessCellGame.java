package model;

import java.util.Random;

/**
 * This class extends GameModel and implements the logic of strategy #1.
 * A description of this strategy can be found in the javadoc for the
 * processCell method.
 * 
 * We define an empty cell as BoardCell.EMPTY. An empty row is defined 
 * as one where every cell corresponds to BoardCell.EMPTY.
 * 
 * @author Department of Computer Science, UMCP
 */

public class ProcessCellGame extends Game {
	
	private final Random random;
	private int strategy;
	private int score = 0;
	
	/**
	 * Defines a board with empty cells. It relies on the super class
	 * constructor to define the board.  The random parameter is used
	 * for the generation of random cells.  The strategy parameter
	 * defines which processing cell strategy to use (for this project
	 * the default will be 1).
	 * 
	 * @param maxRows
	 * @param maxCols
	 * @param random
	 * @param strategy
	 */
	public ProcessCellGame(int maxRows, int maxCols, Random random, int strategy) {
		super(maxRows, maxCols);
		super.setBoardWithColor(BoardCell.EMPTY);
		this.random = random;
		this.strategy = strategy;
	}

	/**
	 * The game is over when the last board row (row with index board.length -1)
	 * is different from empty row.
	 */
	public boolean isGameOver() {
		//use the shortened function I made so I can not rewrite code to find a empty line.
		return !rowEmpty(getMaxRows()-1);
//		if (isRowEmpty(getMaxRows()-1)) {
//			return false;
//		} else {
//			return true;
//		}
	}

	public int getScore() {
		return score;
	}

	/**
	 * This method will attempt to insert a row of random BoardCell objects if
	 * the last board row (row with index board.length -1) corresponds to the
	 * empty row; otherwise no operation will take place.
	 */
	public void nextAnimationStep() {
		//Check if the last row is empty
		if (rowEmpty(getMaxRows()-1)) {
			//if empty move everything down
			for (int i=getMaxRows()-2; i >= 0; i--) {
				for (int h=0; h<getMaxCols(); h++) {
					setBoardCell(i+1, h, board[i][h]);
				}
			}
			//update random row
			for (int i=0; i<getMaxCols(); i++) {
				setBoardCell(0, i, BoardCell.getNonEmptyRandomBoardCell(this.random));
			}
		}
		//if full then don't do anything
	}

	/**
	 * The default processing associated with this method is that for
	 * strategy #1. If you add a new strategy, make sure you add
	 * a conditional so the processing described below is associated with
	 * strategy #1.
	 * <br><br>
	 * Strategy #1 Description.<br><br>
	 * This method will turn to BoardCell.EMPTY the cell selected and any
	 * adjacent surrounding cells in the vertical, horizontal, and diagonal
	 * directions that have the same color. The clearing of adjacent cells
	 * will continue as long as cells have a color that corresponds to the 
	 * selected cell. Notice that the clearing process does not clear every 
	 * single cell that surrounds a cell selected (only those found in the 
	 * vertical, horizontal or diagonal directions).
	 * <br>
	 * IMPORTANT: Clearing a cell adds one point to the game's score.<br>
	 * <br>
	 * 
	 * If after processing cells, any rows in the board are empty,those
	 * rows will collapse, moving non-empty rows upward. For example, if 
	 * we have the following board (an * represents an empty cell):<br />
	 * <br />
	 * RRR<br />
	 * GGG<br />
	 * YYY<br />
	 * * * *<br/>
	 * <br />
	 * then processing each cell of the second row will generate the following
	 * board<br />
	 * <br />
	 * RRR<br />
	 * YYY<br />
	 * * * *<br/>
	 * * * *<br/>
	 * <br />
	 * IMPORTANT: If the game has ended no action will take place.
	 * 
	 * 
	 */
	public void processCell(int rowIndex, int colIndex) {
		//check strategy or if the game has ended
		if (!isGameOver()) {
			if (strategy == 1) {
				//find the state of the current cell
				BoardCell selected = board[rowIndex][colIndex];
				//if the current cell is empty don't do anything
				if (selected != BoardCell.EMPTY) {
					//increase the score by 1 and set to empty
					score++;
					setBoardCell(rowIndex, colIndex, BoardCell.EMPTY);
					//go out in each direction using a assistant method Check offset
					//not sure if I could iterate over for this so this is what you get
					
					checkOffset(1,1, selected, rowIndex, colIndex);//down right
					checkOffset(1,0, selected, rowIndex, colIndex);//down
					checkOffset(1,-1, selected, rowIndex, colIndex);//down left
					checkOffset(0,1, selected, rowIndex, colIndex);//right
					checkOffset(0,-1, selected, rowIndex, colIndex);//left
					checkOffset(-1,1, selected, rowIndex, colIndex);//up right
					checkOffset(-1,0, selected, rowIndex, colIndex);//up
					checkOffset(-1,-1, selected, rowIndex, colIndex);//up left
					
					//check for empty rows from the bottom to the top by moving each up
					int fillerValue =0; //used to add to the amount based on loop number
					for (int i=getMaxRows()-2; i >= 0; i--) {
						fillerValue++;
						if (rowEmpty(i)) {
							//if empty move everything up on the rows between i and max rows
							for (int h=0; h<getMaxCols(); h++) {
								//for loop to handle all the mid (possibly works)
								for (int f=0; f<fillerValue; f++) {
									setBoardCell(i+f, h, board[i+1+f][h]);
								}
							}
						}
					}
					//replace the bottom row with empty blocks	
					for (int i=0; i<getMaxCols(); i++) {
						setBoardCell(getMaxRows()-1, i, BoardCell.EMPTY);
					}
				}
			}
		}
	}
	
	//I put this in to speed things up because I needed to write it multiple times. :)
	private boolean rowEmpty(int rowIndex) {
		//create variables
		boolean output = true;
		BoardCell[] row = board[rowIndex];
		//search through the last row if it is empty
		for (BoardCell point : row) {
			if (point != BoardCell.EMPTY) {
				output = false;
			}
		}
		//if all are empty false will be returned else true will be returned.
		return output;
	}
	
	//recursive method to check the directions quickly without large amounts of code
	private void checkOffset(int rowOffset, int colOffset, BoardCell state, int row, int col) {
		int mainRow = row + rowOffset;
		int mainCol = col + colOffset;
		if ((mainCol >= 0) && (mainCol < getMaxCols()) && (mainRow >= 0) && (mainRow < getMaxRows()) && (getBoardCell(mainRow, mainCol) == state)) {
			score++;
			setBoardCell(mainRow, mainCol, BoardCell.EMPTY);
			checkOffset(rowOffset, colOffset, state, mainRow, mainCol);
		}
	}
}