package Test1;

public class Pet {
	public int one;
	
    public Pet(){
        one = 1;	
        System.out.println("sound");	
    }
	
    public Pet(int one){
        System.out.println("silent");
        this.one = one;			
    }
	
    public int method (){
        return one + 2;			
    }

}
