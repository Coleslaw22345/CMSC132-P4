package Test1;

public class ClassThree extends ClassTwo {
	private int amount;
	
	public ClassThree( ) {
		super(3, 6);
		System.out.println("three");
	}
	
	public ClassThree(int amount) {
		super(amount);
		System.out.println("three more");
		this.amount = process();
	}
	
	public int process() {
		return super.process() + amount * 3 / 0;
	}
}
