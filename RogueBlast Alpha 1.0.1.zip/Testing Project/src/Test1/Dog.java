package Test1;

public class Dog extends Pet{
	private int two;
	
    public Dog(){
        two = 2;
        System.out.println("woof");	
    }
	
    public Dog(int two){
        super(two);
        System.out.println("bark");
        this.two = two;
    }
	
    public Dog(int two, int one){
        super(two);
        System.out.println("bow wow");
        this.two = super.one;
    }

    public int method (){
         return super.method () + two * 3;
    }

}
