package Test1;

public class class1 {
	static public void main(String[] args) {
		System.out.println("1");
		ClassOne a = new ClassOne();
		System.out.println("1");
		ClassTwo b = new ClassTwo(1);
		//System.out.println("1");
		//ClassOne d = new ClassThree(3);
		//System.out.println("1");
		//ClassThree f = new ClassThree(4);
		System.out.println("");
		
		System.out.println("1");
		System.out.println(a.process());
		System.out.println("1");
		System.out.println(b.process());
		//System.out.println("1");
		//System.out.println(d.process());
		//System.out.println("1");
		//System.out.println(f.process());
	}
}
