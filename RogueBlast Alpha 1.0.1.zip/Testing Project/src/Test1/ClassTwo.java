package Test1;

public class ClassTwo extends ClassOne{
	  protected int value;
		
	  public ClassTwo() {
	    super(2);
	    System.out.println("two");
	  }
		
	  public ClassTwo(int value) {
	    super(4);
	    System.out.println("two more");
	    this.value = value;
	  }
		
	  public ClassTwo(int value, int number) {
	    super(number);
	    System.out.println("more two");
	    this.value = value;
	  }
		
	  public int process() {
	    return super.process() + value * 2;
	  }
}

