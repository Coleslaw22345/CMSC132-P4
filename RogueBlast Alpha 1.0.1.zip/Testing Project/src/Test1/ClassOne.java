package Test1;

public class ClassOne {
	private int number;
	
	public ClassOne() {
		System.out.println("one");
	}
	
	public ClassOne(int number) {
	  System.out.println("one more");
		this.number = number;
	}
	
	public int process() {
		return number + 1;
	}
}

