package game;

import java.awt.Graphics;

public class Entity {
	private Point pos;
	
	private double maxHealth;
	private double health;
	
	private Polygon[] model;
	
	public Entity(Polygon poly) {
		pos = new Point(50, 50);
		maxHealth = 10;
		health = 10;
	}
	
	
	public void draw(Graphics brush) {
		
	}
	
	public Point getPoint() {
		return this.pos;
	}
	
	public double getHealth() {
		return health;
	}
	
	public double getMaxHealth() {
		return maxHealth;
	}
	
	public void damage(double damage) {
		//TODO
	}
}
